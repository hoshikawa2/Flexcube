cd /
su - gsh
wget https://objectstorage.us-ashburn-1.oraclecloud.com/p/wjZLccY8yvJhr3mRDSeJAdy3JSaDf0MiOWxCcHzkgP1AivCU0U4S6aX3DPRJHNw9/n/id3kyspkytmr/b/bucket_banco_conceito/o/kernel144_11Mar21.zip

unzip kernel144_11Mar21.zip
mv scratch/gsh/kernel144/ /scratch/gsh
cd /scratch/gsh/kernel144/user_projects/domains/integrated/bin
